"""AI Based Student Management System - Flask backend. Run: python app.py"""
import os
import random
from functools import wraps

from dotenv import load_dotenv
from flask import (Flask, flash, jsonify, redirect, render_template, request,
                   session, url_for)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

import ai_engine

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///students.db"
db = SQLAlchemy(app)


# ---------------- Models ----------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    roll_no = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120))
    course = db.Column(db.String(80), nullable=False)
    year = db.Column(db.Integer, default=1)
    attendance = db.Column(db.Float, default=0)      # %
    avg_marks = db.Column(db.Float, default=0)       # %
    assignments = db.Column(db.Float, default=0)     # % completed
    study_hours = db.Column(db.Float, default=0)     # per week
    risk_level = db.Column(db.String(10), default="Low")
    risk_score = db.Column(db.Float, default=0)
    grade = db.Column(db.String(3), default="-")

    def run_ai(self):
        self.risk_level, self.risk_score = ai_engine.predict_risk(
            self.attendance, self.avg_marks, self.assignments, self.study_hours)
        self.grade = ai_engine.predicted_grade(self.attendance, self.avg_marks, self.assignments)


# ---------------- Helpers ----------------
def login_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **kw)
    return wrapper


def num(field, lo=0, hi=100):
    try:
        return max(lo, min(hi, float(request.form.get(field, 0))))
    except ValueError:
        return lo


def fill(student):
    f = request.form
    student.roll_no = f["roll_no"].strip()
    student.name = f["name"].strip()
    student.email = f.get("email", "").strip()
    student.course = f["course"].strip()
    student.year = int(num("year", 1, 6))
    student.attendance = num("attendance")
    student.avg_marks = num("avg_marks")
    student.assignments = num("assignments")
    student.study_hours = num("study_hours", 0, 80)
    student.run_ai()


def seed():
    if not User.query.first():
        db.session.add(User(username="admin", password_hash=generate_password_hash("admin123")))
    if not Student.query.first():
        rng = random.Random(7)
        names = ["Aarav Sharma", "Diya Reddy", "Rohan Gupta", "Ananya Iyer", "Karthik Rao", "Sneha Patel",
                 "Vikram Singh", "Meera Nair", "Arjun Das", "Priya Menon", "Rahul Verma", "Isha Kapoor",
                 "Tanvi Joshi", "Siddharth Jain", "Neha Bansal", "Aditya Kulkarni", "Pooja Shetty", "Manish Yadav"]
        courses = ["B.Tech CSE", "B.Tech ECE", "BBA", "B.Sc Data Science"]
        for i, n in enumerate(names, 1):
            s = Student(roll_no=f"R{100 + i}", name=n, email=f"{n.split()[0].lower()}@college.edu",
                        course=rng.choice(courses), year=rng.randint(1, 4),
                        attendance=round(rng.uniform(45, 98), 1), avg_marks=round(rng.uniform(30, 95), 1),
                        assignments=round(rng.uniform(30, 100), 1), study_hours=round(rng.uniform(2, 28), 1))
            s.run_ai()
            db.session.add(s)
    db.session.commit()


# ---------------- Auth ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(username=request.form["username"].strip()).first()
        if u and check_password_hash(u.password_hash, request.form["password"]):
            session["user"] = u.username
            return redirect(url_for("dashboard"))
        flash("Wrong username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------- Pages ----------------
@app.route("/")
@login_required
def dashboard():
    students = Student.query.all()
    n = len(students)
    stats = {
        "total": n,
        "avg_marks": round(sum(s.avg_marks for s in students) / n, 1) if n else 0,
        "avg_att": round(sum(s.attendance for s in students) / n, 1) if n else 0,
        "risk": {k: sum(1 for s in students if s.risk_level == k) for k in ["Low", "Medium", "High"]},
    }
    at_risk = sorted([s for s in students if s.risk_level == "High"], key=lambda s: -s.risk_score)[:6]
    return render_template("dashboard.html", stats=stats, at_risk=at_risk)


@app.route("/students")
@login_required
def students():
    q = request.args.get("q", "").strip()
    query = Student.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Student.name.ilike(like), Student.roll_no.ilike(like), Student.course.ilike(like)))
    return render_template("students.html", students=query.order_by(Student.name).all(), q=q)


@app.route("/students/add", methods=["GET", "POST"])
@login_required
def add_student():
    if request.method == "POST":
        if Student.query.filter_by(roll_no=request.form["roll_no"].strip()).first():
            flash("That roll number already exists.", "error")
            return render_template("student_form.html", s=None)
        s = Student()
        fill(s)
        db.session.add(s)
        db.session.commit()
        flash("Student added.", "ok")
        return redirect(url_for("student_detail", sid=s.id))
    return render_template("student_form.html", s=None)


@app.route("/students/<int:sid>")
@login_required
def student_detail(sid):
    s = db.get_or_404(Student, sid)
    tips = ai_engine.recommendations(s.attendance, s.avg_marks, s.assignments, s.study_hours)
    return render_template("student_detail.html", s=s, tips=tips)


@app.route("/students/<int:sid>/edit", methods=["GET", "POST"])
@login_required
def edit_student(sid):
    s = db.get_or_404(Student, sid)
    if request.method == "POST":
        fill(s)
        db.session.commit()
        flash("Student updated.", "ok")
        return redirect(url_for("student_detail", sid=s.id))
    return render_template("student_form.html", s=s)


@app.route("/students/<int:sid>/delete", methods=["POST"])
@login_required
def delete_student(sid):
    db.session.delete(db.get_or_404(Student, sid))
    db.session.commit()
    flash("Student deleted.", "ok")
    return redirect(url_for("students"))


@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():
    question = (request.get_json(silent=True) or {}).get("message", "").strip()
    if not question:
        return jsonify(reply="Please type a question."), 400
    return jsonify(reply=ai_engine.chat(question, Student.query.all()))


with app.app_context():
    db.create_all()
    seed()

if __name__ == "__main__":
    app.run(debug=True)
