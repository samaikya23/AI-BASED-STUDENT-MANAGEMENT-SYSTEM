"""AI layer: (1) ML risk model, (2) recommendations, (3) chat assistant.
The model is a softmax (multinomial logistic) regression written in pure Python,
so it needs no scikit-learn or numpy."""
import json
import math
import os
import random

MODEL_PATH = os.path.join(os.path.dirname(__file__), "risk_model.json")
LABELS = ["Low", "Medium", "High"]


def _features(attendance, marks, assignments, study_hours):
    return [attendance / 100, marks / 100, assignments / 100, min(study_hours, 30) / 30, 1.0]


def _synthetic_data(n=600, seed=42):
    """Synthetic training data. Replace with real historical records for production."""
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        att, marks = rng.uniform(40, 100), rng.uniform(25, 100)
        asg, hrs = rng.uniform(20, 100), rng.uniform(0, 30)
        score = (0.35 * (100 - att) + 0.40 * (100 - marks) + 0.15 * (100 - asg)
                 + 0.10 * (30 - hrs) / 30 * 100 + rng.gauss(0, 4))
        y = 0 if score < 30 else 1 if score < 45 else 2
        rows.append((_features(att, marks, asg, hrs), y))
    return rows


def _softmax(z):
    m = max(z)
    e = [math.exp(v - m) for v in z]
    s = sum(e)
    return [v / s for v in e]


def _probs(W, x):
    return _softmax([sum(w * xi for w, xi in zip(row, x)) for row in W])


def train_model(epochs=400, lr=1.5):
    data = _synthetic_data()
    W = [[0.0] * 5 for _ in range(3)]
    for _ in range(epochs):
        grad = [[0.0] * 5 for _ in range(3)]
        for x, y in data:
            p = _probs(W, x)
            for k in range(3):
                err = p[k] - (1 if k == y else 0)
                for j in range(5):
                    grad[k][j] += err * x[j]
        for k in range(3):
            for j in range(5):
                W[k][j] -= lr * grad[k][j] / len(data)
    with open(MODEL_PATH, "w") as f:
        json.dump(W, f)
    return W


def _load_model():
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH) as f:
            return json.load(f)
    return train_model()


_model = None


def predict_risk(attendance, marks, assignments, study_hours):
    """Returns (label, risk_score 0-100)."""
    global _model
    if _model is None:
        _model = _load_model()
    p = _probs(_model, _features(attendance, marks, assignments, study_hours))
    label = LABELS[p.index(max(p))]
    return label, round((p[1] * 0.5 + p[2]) * 100, 1)


def predicted_grade(attendance, marks, assignments):
    s = 0.6 * marks + 0.2 * attendance + 0.2 * assignments
    for cut, g in [(90, "A+"), (80, "A"), (70, "B"), (60, "C"), (50, "D")]:
        if s >= cut:
            return g
    return "F"


def recommendations(attendance, marks, assignments, study_hours):
    tips = []
    if attendance < 75:
        tips.append("Attendance is below 75%. Meet the student and agree on a plan to attend regularly.")
    if marks < 50:
        tips.append("Marks are low. Assign a peer mentor and schedule remedial classes.")
    elif marks < 65:
        tips.append("Marks are average. Share practice tests on the weakest topics.")
    if assignments < 60:
        tips.append("Many assignments are missing. Set short weekly deadlines with reminders.")
    if study_hours < 8:
        tips.append("Study time is under 8 hours a week. Suggest a daily study routine.")
    return tips or ["The student is on track. Keep encouraging steady progress."]


# ---------------- Chat assistant ----------------
def _context(students):
    if not students:
        return "No students in the system."
    n = len(students)
    avg_m = sum(s.avg_marks for s in students) / n
    avg_a = sum(s.attendance for s in students) / n
    high = [s for s in students if s.risk_level == "High"]
    lines = [f"Total students: {n}", f"Average marks: {avg_m:.1f}", f"Average attendance: {avg_a:.1f}%",
             f"High-risk students: {len(high)}", "Students (name | course | marks | attendance | risk):"]
    lines += [f"{s.name} | {s.course} | {s.avg_marks} | {s.attendance} | {s.risk_level}" for s in students[:80]]
    return "\n".join(lines)


def _fallback(question, students):
    q = question.lower()
    if not students:
        return "There are no students yet. Add some from the Students page."
    n = len(students)
    if "risk" in q:
        high = [s.name for s in students if s.risk_level == "High"]
        return (f"{len(high)} student(s) are high risk: " + ", ".join(high[:10])) if high else "No students are high risk."
    if "top" in q or "best" in q:
        top = sorted(students, key=lambda s: s.avg_marks, reverse=True)[:3]
        return "Top performers: " + ", ".join(f"{s.name} ({s.avg_marks})" for s in top)
    if "attendance" in q:
        return f"Average attendance is {sum(s.attendance for s in students) / n:.1f}%."
    if "average" in q or "marks" in q:
        return f"Average marks are {sum(s.avg_marks for s in students) / n:.1f}."
    if "how many" in q or "count" in q or "total" in q:
        return f"There are {n} students."
    return ("I can answer about risk, top performers, attendance, average marks and counts. "
            "Add ANTHROPIC_API_KEY to .env for full AI answers.")


def chat(question, students):
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return _fallback(question, students)
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        resp = client.messages.create(
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"),
            max_tokens=500,
            system=("You are an assistant inside a student management system for teachers. "
                    "Answer briefly using only this data:\n" + _context(students)),
            messages=[{"role": "user", "content": question}],
        )
        return resp.content[0].text
    except Exception as e:  # network/key problems -> still useful
        return f"AI service unavailable ({type(e).__name__}). " + _fallback(question, students)
