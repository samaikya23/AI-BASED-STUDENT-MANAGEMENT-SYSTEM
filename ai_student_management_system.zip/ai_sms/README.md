# AI Based Student Management System

Flask + SQLite + pure Python ML (+ optional Claude API).

## Features
- Login, add / edit / delete / search students
- ML model (softmax regression, pure Python) predicts dropout/performance risk and a grade from attendance, marks, assignments and study hours
- Personalised suggested actions per student
- Dashboard with risk chart and an AI chat assistant (works offline; uses Claude if `ANTHROPIC_API_KEY` is set)

## Run in VS Code
1. Open this folder in VS Code (File > Open Folder).
2. Terminal > New Terminal, then:
   ```
   python -m venv venv
   venv\Scripts\activate        # Windows   (Mac/Linux: source venv/bin/activate)
   pip install -r requirements.txt
   copy .env.example .env       # Mac/Linux: cp .env.example .env
   python app.py
   ```
3. Open http://127.0.0.1:5000 and log in with **admin / admin123**.

Sample students are created on first run. The ML model trains automatically and is saved as `risk_model.json`.
Replace the synthetic data in `ai_engine._synthetic_data()` with real records for production.

## Structure
```
app.py            routes, database models
ai_engine.py      ML model, recommendations, chat assistant
templates/        HTML pages
static/style.css  styling
requirements.txt  dependencies
.env.example      settings (secret key, API key)
```
